package com.example.androidmysql

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.TableLayout
import android.widget.TextView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException

class MainActivity : AppCompatActivity() {
    var txtNombre:EditText ?= null
    var txtEmail:EditText ?= null
    var txtTelefono:EditText ?= null
    var txtPassword:EditText ?= null
    private var tbUsuarios:TableLayout?=null




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtNombre = findViewById(R.id.txtNombre)
        txtEmail = findViewById(R.id.txtEmail)
        txtTelefono = findViewById(R.id.txtTelefono)
        txtPassword = findViewById(R.id.txtPassword)

        tbUsuarios = findViewById((R.id.tbUsuarios))
        tbUsuarios?.removeAllViews()

        cargaTabla()

    }

    @SuppressLint("InflateParams")
    private fun cargaTabla(){
        tbUsuarios?.removeAllViews()
        val queue = Volley.newRequestQueue(this)
        val url = "http://192.168.0.6/android_mySQL/registros.php"

        val myJsonObjectRequest = JsonObjectRequest(Request.Method.GET,url,null,
            {
                response ->  try{
                    val myJsonArray = response.getJSONArray("data")
                    for(i in 0 until myJsonArray.length()){
                        val myJSONObject = myJsonArray.getJSONObject(i)
                        val registro = LayoutInflater.from(this).inflate(R.layout.table_row_np,null,false)
                        val colNombre = registro.findViewById<View>(R.id.columnaNombre) as TextView
                        val colEmail = registro.findViewById<View>(R.id.columnaEmail) as TextView
                        val colEditar = registro.findViewById<View>(R.id.colEditar)
                        val colBorrar = registro.findViewById<View>(R.id.colBorrar)
                        colNombre.text= myJSONObject.getString("nombre")
                        colEmail.text=myJSONObject.getString("email")
                        colEditar.id=myJSONObject.getString("id").toInt()
                        colBorrar.id=myJSONObject.getString("id").toInt()
                        tbUsuarios?.addView(registro)
                    }
                }
                catch (e: JSONException){
                    e.printStackTrace()
                }
            },
            {
                    error ->  Toast.makeText(this,"Error $error",Toast.LENGTH_LONG).show()
            })
        queue.add(myJsonObjectRequest)
    }

    fun clickUpdate() {
        cargaTabla()
    }

    fun clickTablaEditar(view:View){
        val intent = Intent(this, MainActivity2::class.java)
        intent.putExtra("id", view.id.toString())
        startActivity(intent)
    }

    fun clickTablaBorrar(view:View){
        val url = "http://192.168.0.6/android_mySQL/borrar.php"
        val queue = Volley.newRequestQueue(this)
        val resultadoPost = object : StringRequest(
            Method.POST, url,
            Response.Listener {
                    response -> Toast.makeText(this,"El usuario se borro de forma exitosa",Toast.LENGTH_LONG).show()
            }, Response.ErrorListener {
                    error ->  Toast.makeText(this,"Error al crear el usuario:\n $error",Toast.LENGTH_LONG).show()
            }
        ){
            override fun getParams(): MutableMap<String, String> { //Elementos que se van a mandar en el post
                val parametros = HashMap<String,String>()
                parametros["id"] = view.id.toString()
                return parametros
            }
        }
        queue.add(resultadoPost)
        cargaTabla()

    }

    fun clickBtnInsertar() {
        val url = "http://192.168.0.6/android_mySQL/insertar.php"
        val queue = Volley.newRequestQueue(this)

        val resultadoPost = object:StringRequest(
            Method.POST, url,
            Response.Listener {
                    response ->   Toast.makeText(this,"Usuario Insertado Exitosamente", Toast.LENGTH_LONG).show()
            },Response.ErrorListener {
                    error ->  Toast.makeText(this,"Error $error",Toast.LENGTH_LONG).show()
                }){
                override fun getParams(): MutableMap<String, String> {
                    val parametros = HashMap<String,String>()
                    parametros["nombre"] = txtNombre?.text.toString()
                    parametros["email"] = txtEmail?.text.toString()
                    parametros["telefono"] = txtTelefono?.text.toString()
                    parametros["password"] = txtPassword?.text.toString()
                    return parametros
                }
            }
        queue.add(resultadoPost)
        cargaTabla()
    }

    fun clickGet() {
        val txtId = findViewById<EditText>(R.id.txtId)
        val intent = Intent(this, MainActivity2::class.java)
        intent.putExtra("id", txtId.text.toString())
        startActivity(intent)
    }
}